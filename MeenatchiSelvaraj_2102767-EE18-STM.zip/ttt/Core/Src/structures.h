struct getVersion
{
	uint16_t hardware_version;
	uint8_t major;
	uint8_t minor;
	uint16_t build;

};

struct getResolution
{
	uint16_t checksum;
	uint16_t width;
	uint16_t height;
	int cal_checksum;
};


struct getBlock
{
	uint16_t signature;
	uint16_t x;
	uint16_t width;
	uint16_t height;
	int16_t angle;
	uint8_t index;
	uint8_t age;

};